PAVLOV ION
343C4

La rularea scriptului, se obtin cele 3 dendrograme, si clasterizarea punctelor.
Pentru alegerea defintiei de calcul a distantei, se mai paseaza un parametru
functiei unifyCluster

Alegerea numarului optim de clustere, la fel ca in laborator, se face prin
vizualizarea dendogramei


